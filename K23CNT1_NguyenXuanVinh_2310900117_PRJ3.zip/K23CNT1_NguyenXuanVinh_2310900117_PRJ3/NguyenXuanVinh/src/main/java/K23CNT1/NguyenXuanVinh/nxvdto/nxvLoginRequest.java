package K23CNT1.NguyenXuanVinh.nxvdto;
import lombok.Data;

@Data
public class nxvLoginRequest {
    private String username;
    private String password;
}