package K23CNT1.NguyenXuanVinh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NguyenXuanVinhApplicationTests {

	@Test
	void contextLoads() {
	}

}
